/*
 * The Clear BSD License
 * Copyright 2017 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_common.h"
#include "fsl_clock.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static uint32_t CLOCK_Get480PfdFreq(clock_pfd_t pfd);
uint32_t CLOCK_Get528PfdFreq(clock_pfd_t pfd);
extern uint32_t is_cm4_boot(void);

/*******************************************************************************
 * Code
 ******************************************************************************/

uint32_t CLOCK_GetFreq(clock_name_t name)
{
    uint32_t freq;
    uint32_t div;
    uint32_t clockRoot;
    uint32_t clockSrc;
    uint32_t rootClk;
    switch (name)
    {
        case kCLOCK_CpuClk:
            if (is_cm4_boot())
            {
                clockRoot = CCM->CCM_CLOCK_ROOT[kCCM_ClockRootIndex_CM4].CONTROL;
            }
            else
            {
                clockRoot = CCM->CCM_CLOCK_ROOT[kCCM_ClockRootIndex_CM7].CONTROL;
            }
            div = 1 + ((clockRoot & CCM_CONTROL_DIV_MASK) >> CCM_CONTROL_DIV_SHIFT);
            clockSrc = (clockRoot & CCM_CONTROL_MUX_MASK) >> CCM_CONTROL_MUX_SHIFT;
            if (clockSrc == 2)
            {
                rootClk = 400000000u;
            }
            else
            {
                rootClk = CLOCK_GetPllFreq(kCLOCK_PllArm);
            }
            freq = rootClk / div;
            break;

        /* Clock root */
        case kCLOCK_AhbClk:
            /* Periph_clk ---> AHB Clock */
            freq = 0;
            break;

        case kCLOCK_SemcClk:
            /* SEMC alternative clock ---> SEMC Clock */
            freq = 0;
            break;

        case kCLOCK_IpgClk:
            freq = 0;
            break;

        case kCLOCK_RtcClk:
            freq = CLOCK_GetRtcFreq();
            break;
        case kCLOCK_ArmPllClk:
            freq = CLOCK_GetPllFreq(kCLOCK_PllArm);
            break;
        case kCLOCK_480PllClk:
            freq = CLOCK_GetPllFreq(kCLOCK_Pll480);
            break;
        case kCLOCK_480PllPfd0Clk:
            freq = CLOCK_Get480PfdFreq(kCLOCK_Pfd0);
            break;
        case kCLOCK_480PllPfd1Clk:
            freq = CLOCK_Get480PfdFreq(kCLOCK_Pfd1);
            break;
        case kCLOCK_480PllPfd2Clk:
            freq = CLOCK_Get480PfdFreq(kCLOCK_Pfd2);
            break;
        case kCLOCK_480PllPfd3Clk:
            freq = CLOCK_Get480PfdFreq(kCLOCK_Pfd3);
            break;
        case kCLOCK_528PllClk:
            freq = CLOCK_GetPllFreq(kCLOCK_Pll528);
            break;
        case kCLOCK_528PllPfd0Clk:
            freq = CLOCK_Get528PfdFreq(kCLOCK_Pfd0);
            break;
        case kCLOCK_528PllPfd1Clk:
            freq = CLOCK_Get528PfdFreq(kCLOCK_Pfd1);
            break;
        case kCLOCK_528PllPfd2Clk:
            freq = CLOCK_Get528PfdFreq(kCLOCK_Pfd2);
            break;
        case kCLOCK_528PllPfd3Clk:
            freq = CLOCK_Get528PfdFreq(kCLOCK_Pfd3);
            break;
        default:
            freq = 0U;
            break;
    }

    return freq;
}

uint32_t CLOCK_GetPllFreq(clock_pll_t pll)
{
    uint32_t freq;
    switch (pll)
    {
        case kCLOCK_PllArm:
            freq = 798000000ul;
            break;

        case kCLOCK_Pll528:
            /* PLL output frequency = Fref * (DIV_SELECT + NUM/DENOM). */
            freq = 528000000ul;
            break;

        case kCLOCK_Pll480:
            freq = 480000000u;
            break;

        default:
            freq = 0U;
            break;
    }

    return freq;
}

uint32_t CLOCK_Get528PfdFreq(clock_pfd_t pfd)
{
    uint32_t freq = 0;

    switch (pfd)
    {
        case kCLOCK_Pfd0:
            freq = 352000000ul; // 352MHz
            break;

        case kCLOCK_Pfd1:
            freq = 594000000ul; // 594MHz
            break;

        case kCLOCK_Pfd2:
            freq = 396000000ul; // 396MHz
            break;

        case kCLOCK_Pfd3:
            freq = 297000000ul; // 297MHz
            break;

        default:
            freq = 0U;
            break;
    }

    return freq;
}

uint32_t CLOCK_Get480PfdFreq(clock_pfd_t pfd)
{
    uint32_t freq = 0;

    switch (pfd)
    {
        case kCLOCK_Pfd0:
            freq = 664615385ul; // 664.6MHz
            break;

        case kCLOCK_Pfd1:
            freq = 508235941ul; // 508.2MHz
            break;

        case kCLOCK_Pfd2:
            freq = 270000000ul; // 270MHz
            break;

        case kCLOCK_Pfd3:
            freq = 360000000ul; // 360MHz
            break;

        default:
            freq = 0U;
            break;
    }

    return freq;
}
